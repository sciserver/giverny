///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Getdata Demo notebook (C)
//
// supported datasets :
//         - isotropic1024coarse     :  isotropic 1024-cube (coarse).
//         - isotropic1024fine       :  isotropic 1024-cube (fine).
//         - isotropic4096           :  isotropic 4096-cube.
//         - isotropic8192           :  isotropic 8192-cube.
//         - isotropic32768          :  isotropic 32768-cube.
//         - sabl2048low             :  stable atmospheric boundary layer 2048-cube, low-rate timestep.
//         - sabl2048high            :  stable atmospheric boundary layer 2048-cube, high-rate timestep.
//         - stsabl2048low           :  strong stable atmospheric boundary layer 2048-cube, low-rate timestep.
//         - stsabl2048high          :  strong stable atmospheric boundary layer 2048-cube, high-rate timestep.
//         - rotstrat4096            :  rotating stratified 4096-cube.
//         - mhd1024                 :  magneto-hydrodynamic isotropic 1024-cube.
//         - mixing                  :  homogeneous buoyancy driven 1024-cube.
//         - channel                 :  channel flow.
//         - channel5200             :  channel flow (reynolds number 5200).
//         - transition_bl           :  transitional boundary layer.
// functions :
//         - getData  :  retrieve (interpolate and/or differentiate) field data on a set of specified spatial points for the specified variable.        
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// getData
//
// purpose :
//        - retrieve (interpolate and/or differentiate) a group of sparse data points.
// steps : 
//          - step 1    :  identify the database files to be read.
//          - step 2    :  read the database files and store the interpolated points in an array.
// parameters :
//          - dataset   :  the instantiated dataset.
//          - points    :  array of points in the domain [0, 2pi).
//          - variable  :  type of data (velocity, pressure, energy, temperature, force, magneticfield, vectorpotential, density, position).
//          - time      :  time point (snapshot number for datasets without a full time evolution).
//          - time_end  :  ending time point for 'position' variable and time series queries.
//          - delta_t   :  time step for 'position' variable and time series queries.
//          - temporal_method   :  temporal interpolation methods.
//                 - none       :  No temporal interpolation (the value at the closest stored time will be returned).
//                 - pchip      :  Piecewise Cubic Hermite Interpolation Polynomial method is used, in which the value from the two nearest time points
//                    is interpolated at time t using Cubic Hermite Interpolation Polynomial, with centered finite difference evaluation of the
//                    end-point time derivatives (i.e. a total of four temporal points are used).
//          - spatial_method   :  spatial interpolation and differentiation methods.
//                 - none      :  No spatial interpolation (value at the datapoint closest to each coordinate value).
//                 - lag4      :  4th-order Lagrange Polynomial interpolation along each spatial direction.
//                 - lag6      :  6th-order Lagrange Polynomial interpolation along each spatial direction.
//                 - lag8      :  8th-order Lagrange Polynomial interpolation along each spatial direction.
//                 - m1q4      :  Splines with smoothness 1 (3rd order) over 4 data points.
//                 - m2q8      :  Splines with smoothness 2 (5th order) over 8 data points.
//                 - m2q14     :  Splines with smoothness 2 (5th order) over 14 data points.
//                 - fd4noint  :  4th-order centered finite differencing (without spatial interpolation).
//                 - fd6noint  :  6th-order centered finite differencing (without spatial interpolation).
//                 - fd8noint  :  8th-order centered finite differencing (without spatial interpolation).
//                 - fd4lag4   :  4th-order Lagrange Polynomial interpolation in each direction, of the 4th-order finite difference values on the grid.
//           - spatial_operator  :  spatial interpolation and differentiation operator.
//                 - field       :  function evaluation & interpolation.
//                 - gradient    :  differentiation & interpolation.
//                 - hessian     :  differentiation & interpolation.
//                 - laplacian   :  differentiation & interpolation.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "getData.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main() {

    // ----- Initialize getData parameters -----
    const char *auth_token = "edu.jhu.pha.turbulence.testing-201406";
    const char *dataset = "channel";
    const char *spatial_interpolation;
    const char *temporal_interpolation;
    const char *variable;
    const char *spatial_operator;

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // 2D plane demo points : evenly spaced over a 2D plane lying along one of the primary axes
    //     - time     : the time to be queried (snapshot number for datasets without a full time evolution).
    //     - nx, nz   : number of points along each axis. total number of points queried will be n_points = nx * nz.
    //     - x_points, y_points, z_points : point distributions along each axis, evenly spaced over the specified ranges.
    //     - points   : the points array evenly spaced out over the 2D plane.
    //     - points array is instantiated as an empty array that will be filled inside the for loops.
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    spatial_interpolation = "none";
    temporal_interpolation = "none";
    variable = "velocity";
    spatial_operator = "field";
    
    int nx = 64;
    int ny = 1 ;
    int nz = 64;
    int n_points = nx * ny * nz;

    float points[n_points][3];    
    float time = 0;               
      
    // -- Define the ranges for x, y, and z
    double x_start = 0.0, x_end = 0.4 * M_PI;
    double y_start = 0.9;
    double z_start = 0.0, z_end = 0.15 * M_PI;

    double dx = (x_end - x_start) / (nx - 1);
    double dz = (z_end - z_start) / (nz - 1);

    // -- Points array
    int index = 0;
    for (int i = 0; i < nx; i++) {
        double x_value = x_start + i * dx;
        for (int j = 0; j < nz; j++) {
            double z_value = z_start + j * dz;

            points[index][0] = x_value; 
            points[index][1] = y_start;  
            points[index][2] = z_value;  
            
            index++;
        }
    }
	
    printf("\033[1;31m\n ----- Processing 2D plane demo ----- \033[0m");
    printf("\033[1;34m\n ----- Requesting %s at %d points on the 2D plane ...\033[0m\n", variable, n_points);
      
    double **results2D = getData(auth_token, dataset, time, spatial_interpolation, temporal_interpolation, variable, spatial_operator, points, n_points);

    // -- Columns based on the spatial operator and variable
    int num_columns = 3;


    //-------------------------------- Coordinates -------------------------------
    printf("\033[1;34m\n ----- Display coordinates of 10 points where variables are requested ...:\033[0m\n");
    for (int i = 0; i < 10; i++) {
      printf("%d: %13.6e, %13.6e, %13.6e\n", i, points[i][0], points[i][1], points[i][2]);
    }

    //-------------------------------- Velocities --------------------------------
    printf("\033[1;34m\n ----- Display requested velocity at 10 points ...\033[0m\n");
    for (int i = 0; i < 10; i++) {
      printf("%d: %13.6e, %13.6e, %13.6e\n", i, results2D[i][0], results2D[i][1], results2D[i][2]);
    }
       
    // -- Write to VTK file
    printf("\033[1;34m\n ----- Writing 2D output in VTK format \033[0m\n");
    writeVTK("output2D_C.vtk", results2D, nx, ny, nz, num_columns, points);

    free(results2D);

    return 0;
}
