%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Getwindfarmdata Demo notebook (MATLAB)
% 
% supported datasets :
% 
%         - diurnal_windfarm  :  diurnal windfarm.
%         - nbl_windfarm  :  neutral boundary layer windfarm.
%
% functions :
% 
%         - getData  :  retrieve (interpolate and/or differentiate) field data on a set of specified spatial points for the specified variable.      
%         - getTurbineData  :  retrieve turbine data at the specified time for the specified turbine and variable.
%         - getBladeData  :  retrieve blade data on a set of specified spatial points and at the specified time for the specified turbine, blade, and variable.
%         - write_interpolation_tsv_file  :  write getData results to a .tsv file.
%         - write_turbine_tsv_file  :  write getTurbineData results to a .tsv file.
%         - write_blade_tsv_file  :  write getBladeData results to a .tsv file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% instantiate dataset 
%
% purpose :
%        - instantiate the dataset and cache the metadata.
%
% parameters :
% 
%        - auth_token    :  turbulence user authorization token.
%        - dataset_title  :  name of the turbulence dataset.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
clear all;
close all;

% ---- Enter user JHTDB token ----
authkey = 'edu.jhu.pha.turbulence.testing-201406';  
% the above is a default testing token that works for queries up to 4096 points
% for larger queries, please request token at Please send an e-mail to 
% turbulence@lists.johnshopkins.edu including your name, email address, 
% and institutional affiliation and department, together with a short 
% description of your intended use of the database.
%
% ---- select dataset ----
dataset =  'diurnal_windfarm';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% getData 
%
% purpose :
%        - retrieve (interpolate and/or differentiate) a group of sparse data points.
%
% steps :
% 
%          - step 1  :  identify the database files to be read.
%          - step 2  :  read the database files and store the interpolated points in an array.
% 
% parameters :
% 
%          - dataset  :  the instantiated dataset.
%          - points  :  array of points in the domain.
%          - variable  :  type of data.
%                         - vectors  :  velocity, force.
%                         - scalars  :  pressure, temperature, soiltemperature, sgsviscosity.
%          - time  :  time point (snapshot number for datasets without a full time evolution).
%          - time_end  :  ending time point for 'position' variable and time series queries.
%          - delta_t  :  time step for 'position' variable and time series queries.
%          - temporal_method  :  temporal interpolation methods.
%                 - none  :  No temporal interpolation (the value at the closest stored time will be returned).
%                 - pchip  :  Piecewise Cubic Hermite Interpolation Polynomial method is used, in which the value from the two nearest time points
%                    is interpolated at time t using Cubic Hermite Interpolation Polynomial, with centered finite difference evaluation of the
%                    end-point time derivatives (i.e. a total of four temporal points are used).
%          - spatial_method  :  spatial interpolation and differentiation methods.
%                 - none      :  No spatial interpolation (value at the datapoint closest to each coordinate value).
%                 - lag4       :  4th-order Lagrange Polynomial interpolation along each spatial direction.
%                 - lag6       :  6th-order Lagrange Polynomial interpolation along each spatial direction.
%                 - lag8       :  8th-order Lagrange Polynomial interpolation along each spatial direction.
%                 - m1q4     :  Splines with smoothness 1 (3rd order) over 4 data points.
%                 - m2q8     :  Splines with smoothness 2 (5th order) over 8 data points.
%                 - m2q14    :  Splines with smoothness 2 (5th order) over 14 data points.
%                 - fd4noint  :  4th-order centered finite differencing (without spatial interpolation).
%                 - fd6noint  :  6th-order centered finite differencing (without spatial interpolation).
%                 - fd8noint  :  8th-order centered finite differencing (without spatial interpolation).
%                 - fd4lag4   :  4th-order Lagrange Polynomial interpolation in each direction, of the 4th-order finite difference values on the grid.
%           - spatial_operator  :  spatial interpolation and differentiation operator.
%                 - field         :  function evaluation & interpolation.
%                 - gradient   :  differentiation & interpolation.
%                 - hessian    :  differentiation & interpolation.
%                 - laplacian   :  differentiation & interpolation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ----- Initialize getData parameters (except time and points) -----
variable = 'velocity';
temporal_method = 'none'; 
spatial_method = 'lag8';
spatial_operator  = 'field';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% example point distributions (2D plane) are provided below...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2D plane demo points : evenly spaced over a 2D plane lying along one of the primary axes
%     - time : the time to be queried (snapshot number for datasets without a full time evolution).
%     - nx, nz : number of points along each axis. total number of points queried will be n_points = nx * ny.
%     - x_points, y_points, z_points : point distributions along each axis, evenly spaced over the specified ranges.
%     - linspace(axis minimum, axis maximum, number of points).
%     - points : the points array evenly spaced out over the 2D plane.
%     - points array is instantiated as an empty array that will be filled inside the for loops.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% example times corresponding to 17:00:00.00 (7199.0) and 7:00:00.00 (57599.0) respectively.
% the first queryable time for the windfarm datasets is 15:00:01.00.
time = 7199;
time_end = 57599;
delta_t = 3600 * 14;
option = [time_end, delta_t];

nx = 200;
ny = 20;
n_points = nx * ny;
 
points = zeros(n_points,3);

x_points = linspace(0.0, 12862.5, nx);
y_points =  linspace(0.0, 1242.5, ny);
z_points = 90.0;

for i = 1 : nx
    for j = 1 :ny
       points(j +(i - 1) * ny, 1) = x_points(i);
       points(j +(i - 1) * ny, 2) = y_points(j);
       points(j +(i - 1) * ny, 3) = z_points;
    end
end

% ---- GetData ----
fprintf('\nRequesting %s at %i points...\n', variable, n_points);
result = getData(authkey, dataset, variable, time, temporal_method, spatial_method, spatial_operator, points, option);

if (nx >= 2) & (ny >= 2)
    % which component (column) of the data to plot (1-based index, so the first component is specified as 1).
    plot_component = 1;
    
    % which time of the data to plot (0-based index, so the first time component is specified as 0).
    time_component = 1;
    
    % ---- Display sample results on screen ----
    figure1 = figure('Color', [1 1 1], 'InvertHardcopy', 'off', 'PaperSize', [20.98 29.68]);
    axes1 = axes('FontSize', 16, 'LineWidth', 1.5, 'Parent', figure1, ...
        'XScale', 'lin', 'YScale', 'lin', 'Position', [0.18 0.18 0.76 0.76]); 
    box(axes1, 'on'); 
    hold(axes1, 'all'); 

    % plotting data
    results = reshape(result(time_component, :,plot_component), [ny, nx]); 
    contourf(axes1, x_points, y_points, results, 300, 'LineColor','none');
    set(axes1, 'YDir', 'normal');
    colormap('hot')

    % title and labels
    title(['diurnal windfarm', ' ', '(', variable, spatial_operator, ')'], 'FontSize', 15);
    xlabel(axes1, 'X');
    ylabel(axes1, 'Y');
    colorbar('FontSize', 16, 'Parent', figure1);
    set(axes1, 'DataAspectRatio', [1 1 1]); 
    axis tight; 
    set(axes1, 'XTickLabel', axes1.XTick, 'YTickLabel', axes1.YTick); 
    set(axes1, 'TickDir', 'out', 'TickLength', [0.02 0.02]);

    pause(3);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% getTurbineData
%
% purpose :
%        - retrieve turbine data for a specific turbine and set of times.
%
% steps :
%
%         - step 1  :  identify the parquet files to be read.
%         - step 2  :  read the parquet files and store the specified variable data in an array.
%
% parameters :
%
%         - dataset  :  the instantiated dataset.
%         - turbine_variable  :  type of data to retrieve.
%                            - power     :  electrical power output.
%                            - RotSpeed  :  rotational speed.
%                            - thrust    :  aerodynamic thrust.
%                            - Yaw       :  yaw angle of the nacelle.
%         - turbines  :  ID(s) or index(es) of the turbine(s) to retrieve data for.
%         - turbine_times  :  time point(s) at which data is requested.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Turbine time series demo
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

turbine_variable = 'power';

% example turbines
turbines = [1, 7];

% example times: every minute in the domain [15:01:00.00, 14:59:00.00]
turbine_times = double(59:60:86398.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use the tools and processing functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% process turbine data
turbine_result = getTurbineData(authkey, dataset, turbine_variable, turbines, turbine_times);

% select a turbine to display (must match one in the second column)
turbine = 1; 

% filter data for the selected turbine
turbine_data = turbine_result(turbine_result.turbine == turbine, :);

% extract time and variable vectors
time_vec  = turbine_data.time;
value_vec = turbine_data{:, turbine_variable};  


if numel(unique(time_vec)) > 1
    % User-defined plot parameters
    % Green color
    plot_color = [0, 0.5, 0];        
    figsize = [900, 500];            
    
    % plotting
    figure('Position', [100, 100, figsize]); 
    plot(time_vec, value_vec, 'Color', plot_color, 'LineWidth', 0.7);
    hold on;

    %  add plot markers at specific times to match the getData query.
    getdata_times = [7199, 57599];
    getdata_indices = [];

    for i = 1:length(getdata_times)
        match_idx = find(abs(time_vec - getdata_times(i)) < 1e-9, 1); 
        if ~isempty(match_idx)
            getdata_indices(end + 1) = match_idx;
        end
    end

    % plot the plot markers.
    for idx = getdata_indices
        plot(time_vec(idx), value_vec(idx), 'o', 'MarkerSize', 6, 'Color', [0.29, 0, 0.51]); 
    end

    % set up custom x-axis ticks at hourly intervals. one-second shift is because time 0.0 corresponds to 13:00:01.0 ("hh:mm:ss").
    format_tick_time = @(s) mod(15 + floor((s + 1.0) / 3600), 24); 
    min_time = min(time_vec);
    max_time = max(time_vec);
    
    hour_ticks = (floor((min_time + 1.0)/3600)*3600 : ...
                  3600 : ...
                  ceil((max_time + 1.0 + 3600)/3600)*3600) - 1.0;

    % format tick labels
    hour_labels = arrayfun(@(s) sprintf('%02d:00', format_tick_time(s)), hour_ticks, 'UniformOutput', false);

    % set the x-axis limits to have a 1-minute buffer.
    xlim([hour_ticks(1) - 60, hour_ticks(end) + 60 + 1]);
    xticks(hour_ticks);
    xticklabels(hour_labels);
    xtickangle(45);

    % labels and formatting
    dataset_title = 'diurnal windfarm'; 
    title(sprintf('%s (turbine number = %d)', dataset_title, turbine), 'FontSize', 16);
    xlabel('time (hour of day)', 'FontSize', 14);
    ylabel(turbine_variable, 'FontSize', 14);
    grid on;
    set(gca, 'FontSize', 10);
    box on;
    
    pause(3);  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% getBladeData
%
% purpose :
%        - retrieve blade data for a specific turbine, set of times, and actuator points.
%
% steps :
%
%         - step 1  :  identify the parquet files to be read.
%         - step 2  :  read the parquet files and store the specified variable data in an array.
%
% parameters :
%
%         - dataset  :  the instantiated dataset.
%         - blade_variable  :  type of data to retrieve.
%                             - xPos, yPos, zPos            :  blade point coordinates.
%                             - uy_LES1, uy_LES2            :  lateral velocity from LES datasets.
%                             - uy_opt1, uy_opt2            :  lateral velocity from optimization datasets.
%                             - du1, du2                    :  velocity differences.
%                             - alpha                       :  angle of attack.
%                             - Cl, Cd                      :  lift and drag coefficients.
%                             - lift, drag                  :  aerodynamic forces.
%                             - Vrel, Vaxial, Vtangential   :  velocity components.
%                             - axialForce, tangentialForce :  force components.
%         - turbines  :  ID(s) or index(es) of the turbine(s).
%         - blades  :  blade number(s) (typically 0–2).
%         - blade_times  :  time point(s) at which data is requested.
%         - blade_actuator_points  :  index(es) of actuator points on the blade (range: 0 to 99).
%
% output :
%
%         - blade_result  :  DataFrame (or equivalent table) containing the blade values.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Blade time series demo
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

blade_variable = 'alpha';

% example turbines
turbines = [1, 7];

% example blades
blades = [1, 2];

% example times: every minute in the domain [15:01:00.00, 14:59:00.00]
blade_times = double(59:60:86398.5);

% example actuator points on the blades: 19, 39, 59, 79, 99
blade_actuator_points = int64(19:20:99);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use the tools and processing functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% process blade data
blade_result = getBladeData(authkey, dataset, blade_variable, turbines, blades, blade_times, blade_actuator_points);

% select a turbine and blade to display (must match those in blade_result)
turbine = 1;
blade = 1;

% column names correspond to the queried variable and blade actuator points, e.g. {variable}_{actuator point}.
actuator_point = 19;
plot_variable = sprintf('%s_%d', blade_variable, actuator_point);  

% filter the blade_result table for this turbine and blade
blade_data = blade_result((blade_result.turbine == turbine) & (blade_result.blade == blade), :);

% extract time and plot data
time_vec  = blade_data.time;
plot_data = blade_data{:, plot_variable};

if numel(unique(time_vec)) > 1
    % Plot settings
    % green
    plot_color = [0, 0.5, 0];          
    figsize = [900, 500];            

    figure('Position', [100, 100, figsize]);
    plot(time_vec, plot_data, 'Color', plot_color, 'LineWidth', 0.7);
    hold on;

    % add plot markers at specific times to match the getData query.
    getdata_times = [7199, 57599];
    getdata_indices = [];

    for i = 1:length(getdata_times)
        idx = find(abs(time_vec - getdata_times(i)) < 1e-9, 1); 
        if ~isempty(idx)
            getdata_indices(end + 1) = idx;
        end
    end

    % plot the plot markers.
    for idx = getdata_indices
        plot(time_vec(idx), plot_data(idx), 'o', 'MarkerSize', 6, 'Color', [0.29, 0, 0.51]); 
    end

    % convert seconds to hours for x-axis labels.
    format_tick_time = @(s) mod(15 + floor((s + 1.0) / 3600), 24);  
    % set up custom x-axis ticks at hourly intervals. half-second shift is because time 0.0 corresponds to 13:00:00.5 ("hh:mm:ss").
    min_time = min(time_vec);
    max_time = max(time_vec);

    hour_ticks = (floor((min_time + 1.0)/3600)*3600 : ...
                  3600 : ...
                  ceil((max_time + 1.0 + 3600)/3600)*3600) - 1.0;
    
    hour_labels = arrayfun(@(s) sprintf('%02d:00', format_tick_time(s)), hour_ticks, 'UniformOutput', false);

    % apply axis formatting
    xlim([hour_ticks(1) - 60, hour_ticks(end) + 60 + 1]);
    xticks(hour_ticks);
    xticklabels(hour_labels);
    xtickangle(45);

    % labels and title
    dataset_title = 'diurnal windfarm';
    title(sprintf('%s (turbine number = %d, blade number = %d)', dataset_title, turbine, blade), 'FontSize', 16);
    xlabel('time (hour of day)', 'FontSize', 14);
    ylabel(strrep(plot_variable, '_', '\_'), 'FontSize', 14);
    grid on;
    set(gca, 'FontSize', 10);
    box on;
    
    pause(1);
end

