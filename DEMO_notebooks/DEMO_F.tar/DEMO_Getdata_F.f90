!/////////////////////////////////////////////////////////////////////////////////////////////////////////////
!  GetData Demo (Fortran 90)
!
!  Supported datasets:
!       - isotropic1024coarse  : isotropic 1024-cube (coarse).
!       - isotropic1024fine    : isotropic 1024-cube (fine).
!       - isotropic4096        : isotropic 4096-cube.
!       - isotropic8192        : isotropic 8192-cube.
!       - isotropic32768       : isotropic 32768-cube.
!       - sabl2048low          : stable atmospheric boundary layer 2048-cube, low-rate timestep.
!       - sabl2048high         : stable atmospheric boundary layer 2048-cube, high-rate timestep.
!       - stsabl2048low        : strong stable atmospheric boundary layer 2048-cube, low-rate timestep.
!       - stsabl2048high       : strong stable atmospheric boundary layer 2048-cube, high-rate timestep.
!       - rotstrat4096         : rotating stratified 4096-cube.
!       - mhd1024              : magneto-hydrodynamic isotropic 1024-cube.
!       - mixing               : homogeneous buoyancy-driven 1024-cube.
!       - channel              : channel flow.
!       - channel5200          : channel flow (Reynolds number 5200).
!       - transition_bl        : transitional boundary layer.
!
!  Functions:
!       - getData : retrieve (interpolate and/or differentiate) field data on a set of specified spatial points 
!                   for the specified variable.
!/////////////////////////////////////////////////////////////////////////////////////////////////////////////

!/////////////////////////////////////////////////////////////////////////////////////////////////////////////
!  getData
!
!  Purpose:
!       - Retrieve (interpolate and/or differentiate) a group of sparse data points.
!
!  Steps:
!       - Step 1: Identify the database files to be read.
!       - Step 2: Read the database files and store the interpolated points in an array.
!
!  Parameters:
!       - dataset            : The selected dataset.
!       - points             : Array of points in the domain [0, 2π).
!       - variable           : Type of data (velocity, pressure, energy, temperature, force, magneticfield, 
!                              vectorpotential, density, position).
!       - time               : Time point (snapshot number for datasets without a full time evolution).
!       - time_end           : Ending time point for 'position' variable and time series queries.
!       - delta_t            : Time step for 'position' variable and time series queries.
!       - temporal_method    : Temporal interpolation methods.
!           - "none"         : No temporal interpolation (the value at the closest stored time will be returned).
!           - "pchip"        : Piecewise Cubic Hermite Interpolation Polynomial (PCHIP), interpolating from the 
!                              two nearest time points using cubic Hermite polynomials with centered finite 
!                              difference evaluation of the end-point time derivatives (four temporal points used).
!
!       - spatial_method     : Spatial interpolation and differentiation methods.
!           - "none"        : No spatial interpolation (value at the closest grid point).
!           - "lag4"        : 4th-order Lagrange polynomial interpolation along each spatial direction.
!           - "lag6"        : 6th-order Lagrange polynomial interpolation along each spatial direction.
!           - "lag8"        : 8th-order Lagrange polynomial interpolation along each spatial direction.
!           - "m1q4"        : Splines with smoothness 1 (3rd-order) over 4 data points.
!           - "m2q8"        : Splines with smoothness 2 (5th-order) over 8 data points.
!           - "m2q14"       : Splines with smoothness 2 (5th-order) over 14 data points.
!           - "fd4noint"    : 4th-order centered finite differencing (without spatial interpolation).
!           - "fd6noint"    : 6th-order centered finite differencing (without spatial interpolation).
!           - "fd8noint"    : 8th-order centered finite differencing (without spatial interpolation).
!           - "fd4lag4"     : 4th-order Lagrange interpolation in each direction, applied to the 4th-order 
!                             finite difference values on the grid.
!
!       - spatial_operator   : Spatial interpolation and differentiation operator.
!           - "field"       : Function evaluation & interpolation.
!           - "gradient"    : Differentiation & interpolation.
!           - "hessian"     : Differentiation & interpolation.
!           - "laplacian"   : Differentiation & interpolation.
!/////////////////////////////////////////////////////////////////////////////////////////////////////////////

program main
    use, intrinsic :: iso_fortran_env, only: i8 => int64
    use :: getdata_module
    implicit none

    ! ----- Initialize getData parameters -----
    character(80) :: auth_token = "edu.jhu.pha.turbulence.testing-201406"
    character(80) :: dataset = "channel"
    character(80) :: variable = "velocity"
    character(10) :: spatial_interpolation = "none"
    character(10) :: spatial_operator = "field"
    character(20) :: temporal_interpolation = "none"
    real(kind=8) :: time = 0.0

    ! ----- Parameters for 2D Plane
    integer, parameter :: nx = 64, nz = 64
    real(kind=8), dimension(nx * nz, 3) :: points
    real(kind=8), dimension(nx * nz, 3) :: results2D
    real(8) :: x_start, x_end, y_start, z_start, z_end, dx, dz
    integer :: i, j, index
    
    ! -- Number of columns based on spatial operator and variable
    integer :: num_columns
    num_columns = 3
    
    !/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    !  2D Plane Demo Points: Evenly spaced over a 2D plane lying along one of the primary axes.
    !
    !     - time      : The time to be queried (snapshot number for datasets without a full time evolution).
    !     - nx, nz    : Number of points along each axis. The total number of queried points will be:
    !                     n_points = nx * nz
    !     - x_points, y_points, z_points : Point distributions along each axis, evenly spaced over the 
    !                                      specified ranges.
    !     - points    : The points array, evenly spaced out over the 2D plane.
    !     - points array is instantiated as an empty array that will be filled inside the do loops.
    !/////////////////////////////////////////////////////////////////////////////////////////////////////////////

    x_start = 0.0
    x_end = 0.4 * acos(-1.0)
    y_start = 0.9
    z_start = 0.0
    z_end = 0.15 * acos(-1.0)

    dx = (x_end - x_start) / (nx - 1)
    dz = (z_end - z_start) / (nz - 1)

    ! -- Generate points array
    index = 1
    do i = 0, nx - 1
        do j = 0, nz - 1
            points(index, 1) = x_start + i * dx 
            points(index, 2) = y_start           
            points(index, 3) = z_start + j * dz 
            index = index + 1
        end do
    end do
    
    print *, CHAR(27) // '[1;31m' // " ----- Processing 2D plane demo ----- " // CHAR(27) // '[0m'

    print *, CHAR(27) // '[1;34m' // " ----- Requesting " // trim(variable) // &
         " at ", nx * nz, " points on the 2D plane ... " // CHAR(27) // '[0m'

    call getdata(auth_token, dataset, variable, time, &
                 spatial_interpolation, spatial_operator, &
                 temporal_interpolation, points, results2D)


    ! -------------------------------- Coordinates --------------------------------
    print *, CHAR(27) // '[1;34m' // &
         " ----- Display coordinates of 10 points where variables are requested ...:" // &
         CHAR(27) // '[0m'
    
    do i = 1, 10
       print '(I2, 3ES13.6)', i, points(i,1), points(i,2), points(i,3)
    end do
    
    ! -------------------------------- Velocities --------------------------------
    print *, CHAR(27) // '[1;34m' // &
         " ----- Display requested velocity at 10 points ... " // &
         CHAR(27) // '[0m'
    
    do i = 1, 10
       print '(I2, 3ES13.6)', i, results2D(i,1), results2D(i,2), results2D(i,3)
    end do
    
    ! -- Write to VTK file
    print *, CHAR(27) // '[1;34m' // &
         " ----- Writing 2D output in VTK format " // &
         CHAR(27) // '[0m'
    
    call writeVTK("output2D_F.vtk", results2D, nx, nz, 1, 3, points)

end program main
