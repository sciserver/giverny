module getdata_module
    use, intrinsic :: iso_fortran_env, only: i8 => int64
    use, intrinsic :: iso_c_binding
    use :: curl, only: c_f_str_ptr
    implicit none
    private
    public :: response_callback, getdata, writeVTK

    type, public :: response_type
        character(len=:), allocatable :: content
    end type response_type

contains

    function response_callback(ptr, size, nmemb, client_data) bind(c)
        use, intrinsic :: iso_c_binding, only: c_associated, c_f_pointer, c_ptr, c_size_t
        type(c_ptr),            intent(in), value :: ptr
        integer(kind=c_size_t), intent(in), value :: size
        integer(kind=c_size_t), intent(in), value :: nmemb
        type(c_ptr),            intent(in), value :: client_data
        integer(kind=c_size_t)                    :: response_callback
        type(response_type), pointer              :: response
        character(len=:), allocatable             :: buf

        response_callback = int(0, kind=c_size_t)

        if (.not. c_associated(ptr)) return
        if (.not. c_associated(client_data)) return

        call c_f_pointer(client_data, response)
        if (.not. allocated(response%content)) response%content = ''

        call c_f_str_ptr(ptr, buf, nmemb)
        if (.not. allocated(buf)) return
        response%content = response%content // buf
        deallocate(buf)

        response_callback = nmemb
    end function response_callback

    subroutine getdata(auth_token, dataset, var_original, time, &
                       spatial_method_original, spatial_operator_original, &
                       temporal_method_original, points, data_operator_2D)
        use, intrinsic :: iso_fortran_env, only: i8 => int64
        use :: curl
        implicit none

        ! Input arguments
        character(len=*), intent(in) :: auth_token, dataset, var_original
        real(kind=8), intent(in) :: time
        character(len=*), intent(in) :: spatial_method_original, spatial_operator_original
        character(len=*), intent(in) :: temporal_method_original
        real(kind=8), dimension(:,:), intent(in) :: points
        real(kind=8), allocatable, dimension(:,:), intent(out) :: data_operator_2D

        ! Internal variables
        character(len=:), allocatable, target :: points_string, url
        character(20) :: time_str
        character(len=50) :: temp_str
        type(c_ptr) :: curl_ptr, list_ptr
        integer :: rc, i, j, pos, num_count, len_str
        logical :: is_number
        character(len=1) :: ch
        type(response_type), target :: response
        integer :: num_cols
        logical :: is_scalar_var

        integer :: start, finish, count_rate
        real :: elapsed_time

        character(len=128) :: buffer
        integer :: n, len_needed
        
        ! determine number of columns based on variable and spatial operator
        !check if variable is scalar (pressure, sgsenergy, temperature, density)
        is_scalar_var = (trim(var_original) == "pressure" .or. &
                        trim(var_original) == "sgsenergy" .or. &
                        trim(var_original) == "temperature" .or. &
                        trim(var_original) == "density")
        
        ! columns based on variable type and spatial operator
        if (is_scalar_var) then
            if (trim(spatial_operator_original) == "field") then
                num_cols = 1
            else if (trim(spatial_operator_original) == "gradient") then
                num_cols = 3
            else if (trim(spatial_operator_original) == "hessian") then
                num_cols = 6
            else
                stop 'Error: Invalid spatial operator for scalar variable'
            end if
        else
           if (trim(spatial_operator_original) == "field") then
              num_cols = 3
           else if (trim(spatial_operator_original) == "gradient") then
              num_cols = 9
           else if (trim(spatial_operator_original) == "hessian") then
              num_cols = 18
           else if (trim(spatial_operator_original) == "laplacian") then
              num_cols = 3 
           else
              stop 'Error: Invalid spatial operator for vector variable'
           end if
        end if
        
        !Allocate data_operator_2D with the correct number of columns
        allocate(data_operator_2D(size(points,1), num_cols))
        
        ! Convert time from real to string 
        write(time_str, '(F10.6)') time
        time_str = adjustl(time_str)  
    

        ! Calculate the required length for points_string
        n = size(points, 1)

        allocate(character(len=n * 48) :: points_string)

        ! Initialize position in the output string
        pos = 1
        
        ! Loop through each point and write directly into the output string
        do i = 1, n
           ! Format the first coordinate
           write(temp_str, '(F15.8)') points(i, 1)
           points_string(pos:pos+14) = temp_str
           pos = pos + 15
           
           ! Add delimiter
           points_string(pos:pos) = CHAR(9)
           pos = pos + 1
           
           ! Format the second coordinate
           write(temp_str, '(F15.8)') points(i, 2)
           points_string(pos:pos+14) = temp_str
           pos = pos + 15
           
           ! Add delimiter
           points_string(pos:pos) = CHAR(9)
           pos = pos + 1
           
           ! Format the third coordinate
           write(temp_str, '(F15.8)') points(i, 3)
           points_string(pos:pos+14) = temp_str
           pos = pos + 15
           
           ! Add newline
           points_string(pos:pos) = CHAR(10)
           pos = pos + 1
    end do



        ! Print points_string
        !print *, "points_string:"
        !print *, points_string
        !print *, "End of points_string"


    
        ! Initialize cURL
        curl_ptr = curl_easy_init()
        if (.not. c_associated(curl_ptr)) stop 'Error: curl_easy_init() failed'

        list_ptr = curl_slist_append(c_null_ptr, 'Content-Type: text/plain'//c_null_char)

        ! Construct URL
        url = "https://web.idies.jhu.edu/turbulence-svc/values?" // &
             "&authToken=" // trim(auth_token) // &
             "&dataset=" // trim(dataset) // &
             "&function=GetVariable" // &
             "&var="// trim(var_original) // &
             "&t=" // trim(time_str) // &
             "&sint=" // trim(spatial_method_original) //&
             "&sop=" // trim(spatial_operator_original) //&
             "&tint=" // trim(temporal_method_original)

        ! Set curl options
        rc = curl_easy_setopt(curl_ptr, CURLOPT_URL,            url // c_null_char)
        rc = curl_easy_setopt(curl_ptr, CURLOPT_HTTPHEADER,     list_ptr)
        rc = curl_easy_setopt(curl_ptr, CURLOPT_POSTFIELDS,     c_loc(points_string))
        rc = curl_easy_setopt(curl_ptr, CURLOPT_POSTFIELDSIZE,  len(points_string, kind=i8))
        rc = curl_easy_setopt(curl_ptr, CURLOPT_WRITEFUNCTION,  c_funloc(response_callback))
        rc = curl_easy_setopt(curl_ptr, CURLOPT_WRITEDATA,      c_loc(response))

        ! Send request
        rc = curl_easy_perform(curl_ptr)

        ! Debugging: Print cURL error code if request fails
        if (rc /= 0) then
           print *, "cURL request failed with error code:", rc
           stop 'Error: curl_easy_perform() failed'
        end if
        
        ! Print response content
        !print *, "Response content:"
        !print *, response%content
        !print *, "End of response content"

        call curl_easy_cleanup(curl_ptr)

        if (rc /= CURLE_OK) stop 'Error: curl_easy_perform() failed'   
        
        ! Parse JSON response into results2D
        len_str = len_trim(response%content)
        temp_str = ''
        num_count = 0
        is_number = .false.
        
        do pos = 1, len_str
            ch = response%content(pos:pos)

            if ((ch >= '0' .and. ch <= '9') .or. ch == '.' .or. ch == '-' .or. ch == 'e' .or. ch == 'E') then
                temp_str = trim(temp_str) // ch
                is_number = .true.
            else
                if (is_number) then
                    num_count = num_count + 1
                    read(temp_str, *) data_operator_2D((num_count-1)/num_cols + 1, mod(num_count-1,num_cols) + 1)
                    temp_str = ''
                    is_number = .false.
                end if
            end if
         end do
    
    end subroutine getdata

    subroutine reallocate_string(str, new_size)
      character(len=:), allocatable, intent(inout) :: str
      integer, intent(in) :: new_size
      character(len=:), allocatable :: temp
      allocate(character(len=new_size) :: temp)
      temp = str  ! Copy old data
      deallocate(str)
      str = temp  ! Assign resized data
    end subroutine reallocate_string

    subroutine writeVTK(filename, data, nx, ny, nz, num_columns, points)
      implicit none
      character(len=*), intent(in) :: filename
      integer, intent(in) :: nx, ny, nz, num_columns
      real(kind=8), dimension(nx*ny*nz,3), intent(in) :: points
      real(kind=8), dimension(nx*ny*nz,num_columns), intent(in) :: data
      
      integer :: i, j, k, index, col
      open(unit=10, file=filename, status='replace')
      
      ! Write VTK header
      write(10, '(A)') "# vtk DataFile Version 3.0"
      write(10, '(A)') "VTK output"
      write(10, '(A)') "ASCII"
      write(10, '(A)') "DATASET STRUCTURED_GRID"
      write(10, '(A,3I6)') "DIMENSIONS", nx, ny, nz
      write(10, '(A, I6, A)') "POINTS ", nx*ny*nz, " float"

    ! ----------------- Fix Coordinate Writing (Swap Loop Order) -----------------
    index = 1
    do k = 1, nz  ! Match C-order: iterate over Z first
        do j = 1, ny  ! Then iterate over Y
            do i = 1, nx  ! Then iterate over X
                write(10, '(3F15.8)') points(index,1), points(index,2), points(index,3)
                index = index + 1
            end do
        end do
    end do

    ! ----------------- Fix Data Writing (Swap Loop Order) -----------------
    write(10, '(A, I6)') "POINT_DATA", nx*ny*nz
    do col = 1, num_columns
        write(10, '(A, I1, A)') "SCALARS data_", col, " float 1"
        write(10, '(A)') "LOOKUP_TABLE default"
        index = 1
        do k = 1, nz  ! Match C-order: iterate over Z first
            do j = 1, ny  ! Then iterate over Y
                do i = 1, nx  ! Then iterate over X
                    write(10, '(F15.8)') data(index, col)
                    index = index + 1
                end do
            end do
        end do
    end do

    close(10)
end subroutine writeVTK


    
end module getdata_module
